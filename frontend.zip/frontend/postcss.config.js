export default {
  plugins: {
    '@tailwindcss/postcss': {}, // Antes era solo 'tailwindcss'
    autoprefixer: {},
  },
}